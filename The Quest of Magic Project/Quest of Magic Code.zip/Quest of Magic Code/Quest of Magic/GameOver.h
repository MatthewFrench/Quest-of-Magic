//
//  GameOver.h
//  Quest of Magic
//
//  Created by Matthew French on 5/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TitleScreen.h"

@interface GameOver : UIViewController {
    GameData* gameData;
}
- (IBAction)aww;
@end
