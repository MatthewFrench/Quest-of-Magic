//
//  Quest_of_MagicTests.m
//  Quest of MagicTests
//
//  Created by Matthew French on 4/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Quest_of_MagicTests.h"


@implementation Quest_of_MagicTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Quest of MagicTests");
}

@end
