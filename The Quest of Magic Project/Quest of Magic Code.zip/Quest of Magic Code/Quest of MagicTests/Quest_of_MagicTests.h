//
//  Quest_of_MagicTests.h
//  Quest of MagicTests
//
//  Created by Matthew French on 4/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Quest_of_MagicTests : SenTestCase {
@private
    
}

@end
